# Bonjour!

Si vous souhaitez passer immédiatement à l'index des langues, cliquez [ici](indexLangues.md).

## Multilingue? Pourquoi devrais-je l'être?

Test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test 

## Alors, qu'attendez-vous pour apprendre une autre langue? Lancez-vous!

Pour vous rendre sur l'index des langues cliquez [ici](indexLangues.md)!
