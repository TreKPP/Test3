# Index des langues

[Retour à la page principale](index.md)

## Tout d'abord, êtes-vous à l'aise avec la typologie des langues?

Ce site utilisera quelques termes de la typologie des langues. Pour en apprendre plus, cliquez <u>ici</u>.

## Déjà à l'aise avec la typologie des langues? (Ou vous venez tout juste d'en apprendre sur le sujet)

Voici les langues proposées : 

- Langues romanes
- Allemand
- [Japonais (Utilisé pour les tests)](japonais.md)
- Coréen
- Mandarin
- Arabe
